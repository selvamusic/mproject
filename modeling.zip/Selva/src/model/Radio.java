package model;

public class Radio {
	private int sid;
	private String sname;
	private String jianjie; 
	private String img;
	
	public Radio(int sid, String sname, String jianjie,String img) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.jianjie = jianjie;
		this.img = img;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getJianjie() {
		return jianjie;
	}
	public void setJianjie(String jianjie) {
		this.jianjie = jianjie;
	}
	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}
	protected void  addSong() {
			
		}
	protected void addTag() {
		
	  }
}

