package model;

public class Player {
	private int sid;
	private String sname;
    private String volume;
    private String progressbar;  
    private String coveradd;
	
    public Player(int sid,String sname, String volume,String progressbar,String coveradd) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.volume = volume;
		this.progressbar = progressbar;
		this.coveradd = coveradd;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int aid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getVolume() {
		return volume;
	}
	public void setVolume(String volume) {
		this.volume = volume;
	}       
	public String getCoveradd() {
		return coveradd;
	}
	public void setCoveradd(String coveradd) {
		this.coveradd = coveradd;
	}       

	public String getProgressbar() {
		return progressbar;
	}
	public void setProgressbar(String progressbar) {
		this.progressbar = progressbar;
	}    
	protected void play() {
		
	}
   protected void stop() {
	
  }	protected void last() {
		
	}
   protected void next() {
   }
}
