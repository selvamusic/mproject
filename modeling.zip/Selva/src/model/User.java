package model;

import java.sql.*;

import data.DatabaseConnect;


public class User {
      private int uid;
      private String upw;
      private String uname; 
      private String uemail;
      private String img;
  	  private boolean islogin;
	  public User() {
		islogin=false;
	}
   
		public User(int uid, String upw, String uname, String uemail, String img) {
		super();
		this.uid = uid;
		this.upw = upw;
		this.uname = uname;
		this.uemail = uemail;
		this.img = img;
		islogin=true;
		
	}
	public boolean isIslogin() {
		return islogin;
		}
	
	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getUpw() {
		return upw;
	}

	public void setUpw(String upw) {
		this.upw = upw;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUemail() {
		return uemail;
	}

	public void setUemail(String uemail) {
		this.uemail = uemail;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	protected User login(int uid,String upw )throws SQLException, ClassNotFoundException{
		String sql ="select * from userlist where uid="+uid+" and upw='"+upw+"'";
		ResultSet rs = DatabaseConnect.getStat().executeQuery(sql);
		if(rs.next())
			return new User(rs.getInt(1),rs.getString(2),rs.getString(3),
					rs.getString(4),rs.getString(5));
		return new User();
	}
	
    protected void registrer(int uid, String upw, String uname, String uemail,
    		String img) throws SQLException, ClassNotFoundException {
		String sql = "insert into userlist values("+uid+",'"+upw+"','"+uname+"',"+
		uemail+","+img+")";
		DatabaseConnect.getStat().executeUpdate(sql);	
	}
    

    protected void sendComment(int sid,int cid,String commnet) throws SQLException, ClassNotFoundException{
		if(islogin==false)
			return;
		String sql = "insert into commentlist(uid,sid,cid,comment)values("+uid+","+sid+","
		+cid+",'"+commnet+"')";	
		DatabaseConnect.getStat().executeUpdate(sql);	
	}

    protected void  setSonglist() {
		
	}
    
    protected void collectSong(int sid) throws SQLException, ClassNotFoundException {
		if(islogin==false)
			return;
		String sql = "insert into Musicplaylist values("+uid+","+sid+")";
		DatabaseConnect.getStat().executeUpdate(sql);	
}    protected void updatePersonal() {
	
   }
    protected void viewMain() {
		
	}
    protected void viewPersonal() {
		
	}
    protected void viewPlayer() {
	
   }
    protected void viewRadio() {
		
	}
}