package model;

public class Comment {
	private int uid;
    private int vid;
    private int sid;
    private String content; 
    private String time;
    
	public Comment(int uid, int vid, int sid, String content, String time) {
		super();
		this.uid = uid;
		this.vid = vid;
		this.sid = sid;
		this.content = content;
		this.time = time;
	}
	
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public int getVid() {
		return vid;
	}
	public void setVid(int vid) {
		this.vid = vid;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	} 
    
}
