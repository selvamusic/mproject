package model;
import javax.sound.sampled.*;

public class PlayLrc extends Thread{
	public AudioInputStream inputStream;  // ��Ƶ������
	public SourceDataLine dataLine;   // ������������
	public AudioFormat fileFormat;   // ��Ƶ�������
	private static int time;
	private static String str;

	public PlayLrc(int time, String str) {
		setTime(time);
		setStr(str);
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public String getStr() {
		return str;
	}

	public void setStr(String str) {
		this.str = str;
	}
	public void readFile() {    
		
	}
    public void readSong() {
	
	}

	public void parseLine(String line) {
		
	}
    public void run() {

}
    public static void main(String[] args) {
    	// TODO Auto-generated method stub
		PlayLrc playLrc = new PlayLrc(time, str);
		playLrc.readFile();
		playLrc.readSong();
}
}



