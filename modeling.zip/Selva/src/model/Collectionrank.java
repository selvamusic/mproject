package model;

public class Collectionrank {
	private int sid;   
    private int vid;
    private String sname;
    
    public Collectionrank( int sid,int vid, String sname) {
		super();
		this.sid = sid;
		this.vid = vid;
		this.sname = sname;
    }
	public int getVid() {
		return vid;
	}
	public void setVid(int vid) {
		this.vid = vid;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
}
}