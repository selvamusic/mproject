package model;

import java.sql.ResultSet;
import java.sql.SQLException;

import data.DatabaseConnect;

public class Admin {
	private int aid;
    private String apw;
    private boolean islogin;
		public Admin() {
		islogin=false;
			}
		
	public Admin(int aid, String apw) {
		super();
		this.aid = aid;
		this.apw = apw;
		islogin=true;
	}
	public boolean isIslogin() {
		return islogin;
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getApw() {
		return apw;
	}
	public void setApw(String apw) {
		this.apw = apw;
	}       
    protected Admin login(int aid,String apw )throws SQLException, ClassNotFoundException{
		String sql ="select * from userlist where uid="+aid+" and upw='"+apw+"'";
		ResultSet rs = DatabaseConnect.getStat().executeQuery(sql);
		if(rs.next())
			return new Admin(rs.getInt(1),rs.getString(2));
		return new Admin();
	}
	
    protected void addAdmin() {
		
	}
    protected void addUser() {
	
   }
    protected void deleteUser() {
		
	}
    protected void seleteUser() {
		
	}
    protected void banUser() {
	
   }
    protected void unbanUser() {
		
	}
    protected void addSong() {
		
	}
    protected void deleteSong() {
	
   }
    protected void  seleteSong() {
		
	}
    protected void updateSong() {
	
   }
   protected void addComment() {
		
	}
    protected void deleteComment() {
		
	}
    protected void seleteComment() {
	
   }
    protected void updateComment() {
		
	}
    protected void addVocalist() {
		
	}
    protected void deleteVocalist() {
	
   }
    protected void seleteVocalist() {
		
	}
    protected void updateVocalist() {
		
	}
}
