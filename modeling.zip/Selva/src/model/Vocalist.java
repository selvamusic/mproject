package model;

import java.sql.ResultSet;
import java.sql.SQLException;

import data.DatabaseConnect;

public class Vocalist {
	private int vid;
    private String vpw; 
    private boolean islogin;
	  public Vocalist() {
		islogin=false;
	}
 
	public Vocalist(int vid, String vpw) {
		super();
		this.vid = vid;
		this.vpw = vpw;
		islogin=true;
	}
	public boolean isIslogin() {
		return islogin;
		}
	
	public int getVid() {
		return vid;
	}
	public void setVid(int vid) {
		this.vid = vid;
	}
	public String getVpw() {
		return vpw;
	}
	public void setVpw(String vpw) {
		this.vpw = vpw;
	}
	
	protected Vocalist login(int vid,String vpw )throws SQLException, ClassNotFoundException{
		String sql ="select * from userlist where uid="+vid+" and upw='"+vpw+"'";
		ResultSet rs = DatabaseConnect.getStat().executeQuery(sql);
		if(rs.next())
			return new Vocalist(rs.getInt(1),rs.getString(2));
		return new Vocalist();
	}
	
	  protected void sendComment () {
			
		}
	    protected void replyComment() {
			
		}
	    protected void addSong() {
			
		}
	    protected void deleteSong() {
		
	   }
	    protected void  seleteSong() {
			
		}
	    protected void updateSong() {
		
	   }
}
