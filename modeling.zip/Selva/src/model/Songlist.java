package model;

public class Songlist {
	private int uid;
    private int sid;
    private String sname;
    private String jianjie; 
    private int love;
    
	public Songlist(int uid, int sid, String sname, String jianjie,int love) {
		super();
		this.uid = uid;
		this.sid = sid;
		this.sname = sname;
		this.jianjie = jianjie;
		this.love = love;
	}
	
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getJianjie() {
		return jianjie;
	}
	public void setJianjie(String jianjie) {
		this.jianjie = jianjie;
	}
	public int getLove() {
		return love;
	}
	public void setLove(int love) {
		this.love = love;
	}
    
}
