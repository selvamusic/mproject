package data;

import java.sql.*;

public class DatabaseConnect {

	private static Statement stat;
	private static void init() throws ClassNotFoundException, SQLException{
		 Class.forName("com.mysql.jdbc.Driver");
		 String url = "jdbc:mysql://localhost:3306/novel?"+ "user=root&password=XXXXXX&useUnicode=true&characterEncoding=UTF8";
		 Connection conn = DriverManager.getConnection(url);
		 stat=conn.createStatement();
		//System.out.println("ok");
	}
//	public static void main(String[] args) {
//		try {
//			getStat();
//		} catch (ClassNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
	public static Statement getStat()throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		if(stat==null)
			init();
		return stat;
	}
}
